package TaskClasses;
public enum TaskCategory {
    SCHOOL,
    WORK,
    APPOINTMENT,
    FAMILY,
    EVENT,
    CHORE,
    OTHER
}
