/**
 * TODO Write a one-sentence summary of your class here.
 * TODO Follow it with additional details about its purpose, what abstraction
 * it represents, and how to use it.
 *
 * @author  TODO Your Name
 * @version Sep 24, 2025
 */
package TimeClasses;
public enum ClockType {
    TWELVE_HOUR,
    TWENTY_FOUR_HOUR;
}
