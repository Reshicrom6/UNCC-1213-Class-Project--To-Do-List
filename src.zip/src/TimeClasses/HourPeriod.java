package TimeClasses;
public enum HourPeriod {
    AM,
    PM;
}